import java.util.*;
public class Quick{

        static void swap(int[] arr,int l, int r){
            int temp = arr[l];
            arr[l] = arr[r];
            arr[r] = temp;
        }
        
        static int partition(int[] arr,int l,int r){
            int pivot = arr[l];
            int i = l;
            int j = r;

            while(i<j){
                while(arr[i]<=pivot && i<r) i++;
                while(arr[j]>pivot && j>=l) j--;
                if(i<j){
                    swap(arr,i,j);
                }
            }

            swap(arr,j,l);
            return j;
        }
        
        static void quickSort(int[] arr,int l, int r){
            if(l<r){
                int p = partition(arr,l,r);
                quickSort(arr,l,p-1);
                quickSort(arr,p+1,r);
            }
        }

        public static void main(String[] args){
        Scanner scan  = new Scanner(System.in);
        System.out.print("Enter no of element: ");
        int n = scan.nextInt();
        int[] arr = new int[n];
        
        for(int i=0;i<n;i++){
            System.out.print("Enter elements: ");
            arr[i] = scan.nextInt();
        }        

        quickSort(arr,0,arr.length-1);   
        System.out.println(Arrays.toString(arr));
    }
}
