import java.util.*;
public class Prims{

    static class Pair implements Comparable<Pair>{
        int w;
        int v;

        Pair(int v,int w){
            this.w = w;
            this.v = v;
        }
        
        public int compareTo(Pair o){
            return this.w - o.w;
        }

    }

    public static void main(String[] args){
        ArrayList<ArrayList<ArrayList<Integer>>> adj = new ArrayList<>();
        
        ArrayList<ArrayList<Integer>> a = new ArrayList<>();
        a.add(new ArrayList<Integer>(Arrays.asList(1,10)));
        a.add(new ArrayList<Integer>(Arrays.asList(3,6)));
        a.add(new ArrayList<Integer>(Arrays.asList(2,2)));

        ArrayList<ArrayList<Integer>> b = new ArrayList<>();
        b.add(new ArrayList<Integer>(Arrays.asList(0,10)));
        b.add(new ArrayList<Integer>(Arrays.asList(1,5)));


        ArrayList<ArrayList<Integer>> c = new ArrayList<>();
        c.add(new ArrayList<Integer>(Arrays.asList(0,2)));
        c.add(new ArrayList<Integer>(Arrays.asList(1,5)));
        c.add(new ArrayList<Integer>(Arrays.asList(3,3)));

        ArrayList<ArrayList<Integer>> d = new ArrayList<>();
        d.add(new ArrayList<Integer>(Arrays.asList(0,6)));
        d.add(new ArrayList<Integer>(Arrays.asList(2,3)));
        
        adj.add(a);
        adj.add(b);
        adj.add(c);
        adj.add(d);

        PriorityQueue<Pair> p = new PriorityQueue<Pair>();
        boolean[] visited = new boolean[adj.size()];

        p.add(new Pair(0,0));
        int totalValue = 0;
        while(p.size()>0){
            Pair curr = p.remove();
            if(!visited[curr.v]){
                totalValue += curr.w;
                System.out.println(curr.v);
                visited[curr.v] =true;
                
                ArrayList<ArrayList<Integer>> neighbours = adj.get(curr.v);
                for(ArrayList<Integer> neighbour: neighbours){
                    if(!visited[neighbour.get(0)]){
                        p.add(new Pair(neighbour.get(0),neighbour.get(1)));
                    }
                }
            }
            
        }

        System.out.println(totalValue);
    }
}
