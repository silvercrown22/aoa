import java.util.*;
public class Merge{
    

    static void merge(int[] arr,int l, int mid, int r){
        int[] newArr = new int[r+1];
        int i = l;
        int j = mid+1;
        int k = l;

        while (i<=mid && j<=r){
            if(arr[i]<arr[j]){
                newArr[k] = arr[i];
                i++;
                k++;
            }
            else{
                newArr[k] = arr[j];
                j++;
                k++;
            }
        }


        if(i>mid){
            while(j<=r){
                newArr[k] = arr[j];
                j++;
                k++;
            }
        }
        else{
            while(i<=mid){
                System.out.println(newArr.length);
                newArr[k] = arr[i];
                i++;
                k++;
            }
        }


        for (int m=0 ; m<=r ; m++){
            arr[m] = newArr[m];
        }
        
    }

    static void mergeSort(int[] arr,int l,int r){
        if(l<r){
            int mid = (l+r)/2;
            mergeSort(arr,l,mid);
            mergeSort(arr,mid+1,r);
            merge(arr,l,mid,r);
        }
    }

    public static void main(String[] args){
        Scanner scan  = new Scanner(System.in);
        System.out.print("Enter no of element: ");
        int n = scan.nextInt();
        int[] arr = new int[n];
        
        for(int i=0;i<n;i++){
            System.out.print("Enter elements: ");
            arr[i] = scan.nextInt();
        }        

        mergeSort(arr,0,arr.length-1);
        
        System.out.println(Arrays.toString(arr));

    }
}
