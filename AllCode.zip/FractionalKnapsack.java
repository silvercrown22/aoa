import java.util.*;
public class FractionalKnapsack{

    static class Item implements Comparable<Item>{
        int val;
        int wt;
        double ratio;
        Item(int val,int wt){
            this.val = val;
            this.wt = wt;
            ratio = val/wt;
        }
        
        public int compareTo(Item o){
            if (this.ratio < o.ratio){
                return 1;
            }
            else if (this.ratio > o.ratio){
                return -1;
            }
            else{
                return 0;
            }
        }
    }
    
    public static int getMax(int capacity,int[] wt,int[] val){
        
        Item[] items = new Item[wt.length];
        
        for(int i=0;i<wt.length;i++){
            items[i] = new Item(val[i],wt[i]);
        }

        Arrays.sort(items);
        int maxValue = 0;        
        for(Item item:items){
            if((capacity-item.wt)>0){
                maxValue += item.val;
                capacity -= item.wt;
            }
            else{
                double frac = capacity/(double)item.wt;
                maxValue += frac * item.val;
                break;
            }
        }

        return maxValue;
    }
    
    public static void main(String[] args){
        int[] wt = {10, 40, 20, 30};
        int[] val = {60, 40, 100, 120};
        int capacity = 50;
        
        int maxVal = getMax(capacity,wt,val);
        
        System.out.println(maxVal);
    }

}
